﻿using KupaKuper_MauiControl.ControlModes;

namespace $safeprojectname$.ViewModes
{
    public partial class HomeViewMode : BaseViewMode
    {
        public override uint ViewIndex { get; set; }
        public override string ViewName { get; set; } = "首页";

        public override void CloseViewVisible()
        {
           
        }

        public override void OnViewVisible()
        {
            
        }

        public override void UpdataView()
        {
            
        }
    }
}
